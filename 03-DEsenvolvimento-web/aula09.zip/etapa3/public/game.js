// game.js

// A função $(document).ready() é um pilar do jQuery.
// Ela garante que todo o código dentro dela só será executado DEPOIS que
// a página HTML estiver completamente carregada e pronta.
// É a forma mais segura de começar a manipular o DOM.
$(document).ready(function() {

    // --- 1. SELEÇÃO DE ELEMENTOS ---
    // Com jQuery, usamos o seletor '$' que é muito parecido com os seletores CSS.
    // É muito mais curto e poderoso que document.getElementById() ou querySelector().
    //const btnStart = document.getElementById('btnStart'); // ficaria assim.
    const btnStart = $('#btnStart');
    const btnPause = $('#btnPause');
    const scoreValue = $('#scoreValue');
    const gameOverScreen = $('#gameOverScreen');
    
    console.log("jQuery carregado e elementos selecionados!");

    // --- 2. MANIPULAÇÃO DE EVENTOS com .on() ---
    // O método .on() é a forma do jQuery de "ouvir" por eventos, como um clique.
    
    // Evento para o botão de Iniciar
    btnStart.on('click', function() {
        console.log("Botão Iniciar clicado!");
        
        // Exemplo de manipulação de DOM:
        // O método .text() altera o conteúdo de texto de um elemento.
        scoreValue.text('0'); 
        
        // O método .hide() esconde um elemento (adiciona display: none).
        gameOverScreen.addClass('hidden');
    });

    // Evento para o botão de Pausar
    btnPause.on('click', function() {
        console.log("Botão Pausar clicado!");
        alert("Jogo pausado! (Funcionalidade a ser implementada)");
    });
    
    // --- 3. MANIPULAÇÃO DE FORMULÁRIOS ---
    $('#scoreForm').on('submit', function(event) {
        // event.preventDefault() impede o comportamento padrão do formulário,
        // que é recarregar a página. Isso nos permite controlar o envio dos dados.
        event.preventDefault();
        
        const playerName = $('#playerName').val(); // .val() pega o valor de um campo de formulário
        
        if (playerName) {
            alert(`Pontuação de ${playerName} será enviada para o servidor!`);
            // Aqui, no futuro, faremos a chamada para o nosso back-end Express.js
        }
    });

});