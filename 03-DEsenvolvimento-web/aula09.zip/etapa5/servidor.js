// servidor.js

// 1. IMPORTAÇÃO DOS MÓDULOS
const express = require('express'); // Importa o framework Express
const fs = require('fs'); // Importa o módulo 'File System' para ler e escrever arquivos
const path = require('path'); // Módulo para trabalhar com caminhos de arquivos

// 2. CONFIGURAÇÃO INICIAL
const app = express(); // Cria uma instância do Express
const PORT = 3000; // Define a porta onde nosso servidor irá rodar
const RANKING_FILE = path.join(__dirname, 'ranking.json'); // Caminho para nosso arquivo de ranking

// 3. MIDDLEWARE
// Middleware para servir arquivos estáticos (HTML, CSS, JS) da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));
// Middleware para analisar o corpo de requisições POST em formato JSON
app.use(express.json());


// 4. DEFINIÇÃO DAS ROTAS DA API

// Rota GET /scores: Para buscar o ranking atual.
function getScores(req, res) {
    console.log("Recebida requisição GET para /scores");
    fs.readFile(RANKING_FILE, 'utf8', function(err, data) {
        // Se o arquivo não existir ou houver um erro, retorna um array vazio.
        if (err) {
            console.log("Arquivo de ranking não encontrado, retornando lista vazia.");
            return res.json([]);
        }
        // Se o arquivo for lido com sucesso, envia os dados como JSON.
        res.json(JSON.parse(data));
    });
}

app.get('/scores', getScores);

// Rota POST /scores: Para salvar uma nova pontuação.
function postScores(req, res) {
    const newScore = req.body; // { name: "Jogador", score: 85 }
    console.log("Recebida requisição POST para /scores com os dados:", newScore);

    // Validação simples dos dados recebidos
    if (!newScore.name || typeof newScore.score === 'undefined') {
        return res.status(400).json({ message: 'Dados inválidos.' });
    }

    fs.readFile(RANKING_FILE, 'utf8', (err, data) => {
        let scores = [];
        if (!err) {
            try {
                scores = JSON.parse(data);
            } catch (parseErr) {
                console.error("Erro ao parsear arquivo de ranking, reiniciando lista:", parseErr);
                scores = [];
            }
        }

        // Adiciona a nova pontuação à lista
        scores.push(newScore);

        // Ordena o ranking pela maior pontuação (mais rebatidas restantes)
        scores.sort((a, b) => b.score - a.score);

        // Mantém apenas os 5 melhores
        const top5 = scores.slice(0, 5);

        // Salva o novo ranking de volta no arquivo
        fs.writeFile(RANKING_FILE, JSON.stringify(top5, null, 2), (err) => {
            if (err) {
                console.error("Erro ao salvar o ranking:", err);
                return res.status(500).json({ message: 'Erro ao salvar pontuação.' });
            }
            console.log("Ranking atualizado com sucesso!");
            res.status(201).json({ message: 'Pontuação salva com sucesso!' });
        });
    });
}

app.post('/scores', postScores);


// 5. INICIALIZAÇÃO DO SERVIDOR
function startServer() {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
    console.log("Acesse a URL no seu navegador para jogar!");
}

app.listen(PORT, startServer);