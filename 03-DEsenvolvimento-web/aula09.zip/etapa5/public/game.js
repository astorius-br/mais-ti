// game.js - Versão com Pontuação Decremental

$(document).ready(function() {
    
    // --- 1. PREPARAÇÃO DO CANVAS E VARIÁVEIS DO JOGO ---

    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');

    let ballRadius = 10;
    let x, y, dx, dy;

    let paddleHeight = 10;
    let paddleWidth = 100;
    let paddleX;

    let rightPressed = false;
    let leftPressed = false;

    let brickRowCount = 3;
    let brickColumnCount = 8;
    let brickWidth = 75;
    let brickHeight = 20;
    let brickPadding = 10;
    let brickOffsetTop = 30;
    let brickOffsetLeft = 30;
    let bricks = [];
    
    // --- MUDANÇAS NA LÓGICA DE PONTUAÇÃO E ESTADO ---
    let score; // A pontuação (rebatidas restantes)
    let bricksLeft; // Contador para saber quando o jogo é vencido
    let gameInterval;

    // --- NOVA VARIÁVEL DE ESTADO ---
    let isPaused = false;

    // --- 2. FUNÇÕES DE DESENHO (Permanecem as mesmas) ---
    // drawBall(), drawPaddle(), drawBricks() não precisam de alteração.

    function drawBall() {
        ctx.beginPath();
        ctx.arc(x, y, ballRadius, 0, Math.PI * 2);
        ctx.fillStyle = "#ffffff";
        ctx.fill();
        ctx.closePath();
    }

    function drawPaddle() {
        ctx.beginPath();
        ctx.rect(paddleX, canvas.height - paddleHeight, paddleWidth, paddleHeight);
        ctx.fillStyle = "#27ae60";
        ctx.fill();
        ctx.closePath();
    }

    function drawBricks() {
        for (let c = 0; c < brickColumnCount; c++) {
            for (let r = 0; r < brickRowCount; r++) {
                if (bricks[c][r].status === 1) {
                    let brickX = (c * (brickWidth + brickPadding)) + brickOffsetLeft;
                    let brickY = (r * (brickHeight + brickPadding)) + brickOffsetTop;
                    bricks[c][r].x = brickX;
                    bricks[c][r].y = brickY;
                    ctx.beginPath();
                    ctx.rect(brickX, brickY, brickWidth, brickHeight);
                    ctx.fillStyle = "#c0392b";
                    ctx.fill();
                    ctx.closePath();
                }
            }
        }
    }

    // --- 3. FUNÇÕES DE LÓGICA E CONTROLE (Com alterações) ---

    function collisionDetection() {
        for (let c = 0; c < brickColumnCount; c++) {
            for (let r = 0; r < brickRowCount; r++) {
                let b = bricks[c][r];
                if (b.status === 1) {
                    if (x > b.x && x < b.x + brickWidth && y > b.y && y < b.y + brickHeight) {
                        dy = -dy;
                        b.status = 0;
                        
                        // --- NOVA LÓGICA DE VITÓRIA ---
                        bricksLeft--;
                        if (bricksLeft <= 0) {
                            // O "return" aqui impede que o jogo continue por mais um frame
                            return gameOver("Você venceu!", true); 
                        }
                    }
                }
            }
        }
    }
    
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawBricks();
        drawBall();
        drawPaddle();
        collisionDetection();

        if (x + dx > canvas.width - ballRadius || x + dx < ballRadius) {
            dx = -dx;
        }

        if (y + dy < ballRadius) {
            dy = -dy;
        } 
        else if (y + dy > canvas.height - ballRadius) {
            if (x > paddleX && x < paddleX + paddleWidth) {
                dy = -dy;
                
                // --- LÓGICA DE PONTUAÇÃO ---
                score++; // Decrementa a pontuação a cada rebatida
                $('#scoreValue').text(score);

                // --- NOVA CONDIÇÃO DE GAME OVER ---
                if (score <= 0) {
                    return gameOver("Sem mais rebatidas!");
                }
            } else {
                // --- CONDIÇÃO DE GAME OVER (Bolinha caiu) ---
                return gameOver("Você perdeu a bolinha!");
            }
        }

        if (rightPressed && paddleX < canvas.width - paddleWidth) {
            paddleX += 7;
        } else if (leftPressed && paddleX > 0) {
            paddleX -= 7;
        }

        x += dx;
        y += dy;
    }

    // --- NOVAS FUNÇÕES PARA PAUSAR O JOGO ---

    // Função para desenhar a tela de "PAUSADO" sobre o canvas
    function drawPauseScreen() {
        ctx.fillStyle = 'rgba(0, 0, 0, 0.5)'; // Fundo semi-transparente
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.font = "50px Arial";
        ctx.fillStyle = "white";
        ctx.textAlign = "center";
        ctx.fillText("PAUSADO", canvas.width / 2, canvas.height / 2);
    }

    // Função que alterna o estado de pausa do jogo
    function togglePause() {
        if (!gameInterval) return; // Não faz nada se o jogo não estiver rodando

        isPaused = !isPaused; // Inverte o estado (true vira false, false vira true)

        if (isPaused) {
            clearInterval(gameInterval); // Para o loop do jogo
            drawPauseScreen(); // Desenha a tela de pausa
            $('#btnPause').text('Retomar'); // Muda o texto do botão
        } else {
            gameInterval = setInterval(draw, 10); // Reinicia o loop do jogo
            $('#btnPause').text('Pausar'); // Volta o texto do botão
        }
    }




    // --- 4. FUNÇÕES DE GERENCIAMENTO DE ESTADO (Com alterações) ---

    // --- 4. FUNÇÕES DE GERENCIAMENTO DE ESTADO (Com alterações) ---

    function startGame() {
        resetGame();
        if(gameInterval) clearInterval(gameInterval);
        
        // --- MODIFICAÇÕES AQUI ---
        isPaused = false; // Garante que o jogo não comece pausado
        $('#btnPause').text('Pausar'); // Reseta o texto do botão
        $('#btnPause').prop('disabled', false); // Habilita o botão de pausar
        // --- FIM DAS MODIFICAÇÕES ---

        gameInterval = setInterval(draw, 10);
        $('#btnStart').text('Reiniciar Jogo');
        $('#gameOverScreen').addClass('hidden');
    }

    function gameOver(message, isVictory = false) {
        clearInterval(gameInterval);
        gameInterval = null; // Limpa a referência ao intervalo
        
        isPaused = true; // Considera o jogo como "pausado" para evitar interações
        $('#btnPause').prop('disabled', true); // Desabilita o botão de pausar
        
        if (isVictory) {
            $('#gameOverScreen h2').text('Você Venceu!');
        } else {
            $('#gameOverScreen h2').text('Fim de Jogo!');
        }
        
        console.log("Fim de jogo:", message);
        $('#finalScore').text(score);
        $('#hiddenScore').val(score);
        $('#gameOverScreen').removeClass('hidden');
    }
    
    function resetGame() {
        x = canvas.width / 2;
        y = canvas.height - 30;
        dx = 4;
        dy = -4;
        paddleX = (canvas.width - paddleWidth) / 2;
        
        // --- INICIALIZAÇÃO DA NOVA LÓGICA DE PONTOS E VITÓRIA ---
        score = 0;
        bricksLeft = brickRowCount * brickColumnCount;
        $('#scoreValue').text(score);
        
        bricks = [];
        for (let c = 0; c < brickColumnCount; c++) {
            bricks[c] = [];
            for (let r = 0; r < brickRowCount; r++) {
                bricks[c][r] = { x: 0, y: 0, status: 1 };
            }
        }
    }


    // --- 5. EVENT LISTENERS (Permanecem os mesmos) ---

    function handleKeyDown(e) {
        if (e.key === "Right" || e.key === "ArrowRight") rightPressed = true;
        else if (e.key === "Left" || e.key === "ArrowLeft") leftPressed = true;
    }

    document.addEventListener("keydown", handleKeyDown, false);

    function handleKeyUp(e) {
        if (e.key === "Right" || e.key === "ArrowRight") rightPressed = false;
        else if (e.key === "Left" || e.key === "ArrowLeft") leftPressed = false;
    }

    document.addEventListener("keyup", handleKeyUp, false);

    $('#btnStart').on('click', startGame);

    // Remove o alert e chama a nova função de toggle
    $('#btnPause').on('click', togglePause);

    // Manipulador de submit, enviando o resultado para o servidor via AJAX
    $('#scoreForm').on('submit', function(event) {
        event.preventDefault();
        
        const playerName = $('#playerName').val();
        const finalScore = parseInt($('#hiddenScore').val());

        console.log(`Enviando pontuação para o servidor: ${playerName} - ${finalScore}`);

        // Usando $.ajax para enviar os dados via POST para o back-end
        $.ajax({
            url: '/scores', // A rota POST que criamos no Express
            method: 'POST',
            contentType: 'application/json', // Informa ao servidor que estamos enviando JSON
            data: JSON.stringify({ name: playerName, score: finalScore }), // Converte nosso objeto JS para uma string JSON
            success: function(response) {
                alert(response.message); // Exibe a mensagem de sucesso do servidor
                
                // Limpa e reseta a interface para um novo jogo
                $('#gameOverScreen').addClass('hidden');
                $('#playerName').val('');
                showInitialMessage();
                
                // Recarrega o ranking para mostrar a nova pontuação!
                loadRanking();
            },
            error: function() {
                alert("Erro ao salvar a pontuação. Tente novamente.");
            }
        });
    });
    
    // Mostra uma mensagem inicial antes do jogo começar
    function showInitialMessage() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.font = "30px Arial";
        ctx.fillStyle = "white";
        ctx.textAlign = "center";
        ctx.fillText("Pressione 'Iniciar Jogo' para começar", canvas.width/2, canvas.height/2);
        
        $('#btnPause').prop('disabled', true); // Desabilita o botão de pausar no início
    }

    // --- NOVA FUNÇÃO PARA COMUNICAÇÃO COM O BACK-END ---

    // Função para carregar e exibir o ranking via AJAX
    function loadRanking() {
        console.log("Buscando o ranking do servidor...");
        $.ajax({
            url: '/scores', // A rota GET que criamos no Express
            method: 'GET',
            success: function(scores) {
                const rankingList = $('#rankingList');
                rankingList.empty(); // Limpa a mensagem "Carregando..."

                if (scores.length === 0) {
                    rankingList.append('<li class="list-group-item">Nenhuma pontuação registrada ainda.</li>');
                    return;
                }

                // Para cada pontuação recebida, cria um item na lista do Bootstrap
                scores.forEach(score => {
                    const listItem = `
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            ${score.name}
                            <span class="badge bg-primary rounded-pill">${score.score}</span>
                        </li>`;
                    rankingList.append(listItem);
                });
            },
            error: function() {
                console.error("Erro ao carregar o ranking.");
                $('#rankingList').html('<li class="list-group-item text-danger">Não foi possível carregar o ranking.</li>');
            }
        });
    }



    showInitialMessage();
    loadRanking(); // Chama a função para carregar o ranking assim que a página estiver pronta

});